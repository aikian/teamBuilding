"""
Generic helper functions for the application.

At the moment this module does not provide any functionality but it
exists as a placeholder for future helpers you may need.
"""

# Currently empty; feel free to add reusable functions here as needed.
